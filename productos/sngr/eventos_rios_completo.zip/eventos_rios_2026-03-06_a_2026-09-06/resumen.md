# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-09-06 06:45:13 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-03-06
- **Hasta**: 2026-09-06
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 292
- **Rango de fechas (real)**: 2026-03-06 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 292 |
