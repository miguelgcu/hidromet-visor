# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-08-13 23:02:51 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-02-13
- **Hasta**: 2026-08-13
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 443
- **Rango de fechas (real)**: 2026-02-13 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 443 |
