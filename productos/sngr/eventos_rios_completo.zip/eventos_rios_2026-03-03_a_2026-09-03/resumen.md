# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-09-03 16:05:20 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-03-03
- **Hasta**: 2026-09-03
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 322
- **Rango de fechas (real)**: 2026-03-03 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 322 |
