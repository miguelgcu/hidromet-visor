# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-08-29 06:09:05 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-02-28
- **Hasta**: 2026-08-29
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 345
- **Rango de fechas (real)**: 2026-02-28 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 345 |
