<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28.0" styleCategories="Symbology">
 <renderer-v2 type="categorizedSymbol" attr="tipo" symbollevels="0" enableorderby="0" forceraster="0">
  <categories>
   <category value="Monitoreo normal" symbol="0" label="Monitoreo normal" render="true"/>
   <category value="Desbordamiento / posible inundacion" symbol="1" label="Desbordamiento / posible inundacion" render="true"/>
   <category value="Crecida / aumento de caudal" symbol="2" label="Crecida / aumento de caudal" render="true"/>
   <category value="Estiaje / bajo caudal" symbol="3" label="Estiaje / bajo caudal" render="true"/>
   <category value="Alerta GEOGLOWS" symbol="4" label="Alerta GEOGLOWS" render="true"/>
   <category value="Sin clasificar" symbol="5" label="Sin clasificar" render="true"/>
  </categories>
  <symbols>
   <symbol alpha="1" type="marker" name="0" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="44,104,222,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
   <symbol alpha="1" type="marker" name="1" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="207,54,43,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
   <symbol alpha="1" type="marker" name="2" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="197,120,27,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
   <symbol alpha="1" type="marker" name="3" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="201,154,46,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
   <symbol alpha="1" type="marker" name="4" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="106,71,206,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
   <symbol alpha="1" type="marker" name="5" clip_to_extent="1" force_rhr="0">
    <layer class="SimpleMarker" enabled="1" locked="0" pass="0">
     <prop k="color" v="100,116,139,255"/>
     <prop k="name" v="circle"/>
     <prop k="outline_color" v="255,255,255,255"/>
     <prop k="outline_width" v="0.35"/>
     <prop k="outline_width_unit" v="MM"/>
     <prop k="size" v="2.8"/>
     <prop k="size_unit" v="MM"/>
    </layer>
   </symbol>
  </symbols>
 </renderer-v2>
</qgis>
