# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-09-10 18:37:13 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-03-10
- **Hasta**: 2026-09-10
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 256
- **Rango de fechas (real)**: 2026-03-10 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 256 |
