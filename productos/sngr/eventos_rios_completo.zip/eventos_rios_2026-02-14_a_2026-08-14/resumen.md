# Eventos de Ríos (SNGR) — resumen de la selección

Generado: 2026-08-14 21:46:32 · HidroMet Ecuador

## Filtros aplicados

- **Tipo de evento**: Todas
- **Provincia**: Todas
- **Cantón**: Todos
- **Parroquia**: Todas
- **Desde**: 2026-02-14
- **Hasta**: 2026-08-14
- **Búsqueda**: —

## Estadísticas

- **Total de eventos**: 435
- **Rango de fechas (real)**: 2026-02-15 → 2026-07-20
- **Personas afectadas (suma)**: 0
- **Familias afectadas (suma)**: 0

## Totales por año

| Año | Eventos |
|---|---|
| 2026 | 435 |
